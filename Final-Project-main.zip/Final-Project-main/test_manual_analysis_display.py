#!/usr/bin/env python3
"""
Test script to verify the manual analysis endpoint returns all 3 models correctly